import{r as s,j as t}from"./chunk-BegflO5J.js";const a=s.forwardRef((r,o)=>t.jsx("body",{...r,ref:o}));a.displayName="Body";export{a as f};
